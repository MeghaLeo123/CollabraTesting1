package Assignment1;

import java.util.Set;

import org.openqa.selenium.chrome.ChromeDriver;

public class Program6 {
		public static void main(String[] args) {
			System.setProperty("webdriver.chrome.driver","C:\\Users\\hp\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe" );
			ChromeDriver driver = new ChromeDriver();
			driver.get("https://www.naukri.com");
			Set<String> allWindowIds = driver.getWindowHandles();
		    for(String title: allWindowIds) {
		    driver.switchTo().window(title);
		    System.out.println(driver.getTitle());
		    
			
		    }
		

	}

}
